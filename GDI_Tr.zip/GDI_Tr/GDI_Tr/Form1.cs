﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GDI_Tr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(MessageBox.Show("Warning 1\nAre you want to run this malware?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                Environment.Exit(-1);
            }
            else
            {
                if (MessageBox.Show("Warning 2\nTHIS IS LAST WARNING! ARE YOU SURE?", "Warning 2", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    Environment.Exit(-1);
                }
                else
                {
                    var virus = new Form2();
                    virus.ShowDialog();
                    this.Close();
                }
            }
        }
    }
}
